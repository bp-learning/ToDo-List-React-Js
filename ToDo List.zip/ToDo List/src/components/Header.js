import React from 'react';
import HighlightIcon from '@mui/icons-material/Highlight';
const Header = () => {
    return (
        <div>
            <header>
                <h1>
                <HighlightIcon />
                ToDoList
                </h1>
                
            </header>
        </div>
    );
}

export default Header;
