import './App.css';
import React, { useState } from "react";
import CreateArea from './components/CreateArea';
import Footer from './components/Footer';
import Header from './components/Header';
import Note from './components/Note';

function App() {

  const [notes,setNotes] = useState([]);

  let addNote=((newNote)=>
  {
    setNotes(prevNotes=>
      {
        return [...prevNotes,newNote]
      })
  })

  let deleteNote=((id)=>
  {
    setNotes(prevNotes=>
      {
        return prevNotes.filter((noteItem,Index)=>
        {
          return Index!==id
        });
      });
  })

  return (
    <div className="App">
     <Header/>
     <CreateArea onAdd={addNote}/>
     {notes.map((noteItem,Index)=>
     {
      return(
        <Note key={Index} id={Index} title={noteItem.title} content={noteItem.content} onDelete={deleteNote}/>
      )
     })}
     <Footer/>
    </div>
  );
}

export default App;
